const projectName = 'product-landing-page';
localStorage.setItem('example_project', 'Product Landing Page');